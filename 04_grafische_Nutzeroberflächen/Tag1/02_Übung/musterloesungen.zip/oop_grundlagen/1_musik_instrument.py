# Definition der Klasse Instrument
class Instrument:
    def __init__(self, name, typ):
        self.name = name              # z.B. "Gitarre"
        self.typ = typ                # z.B. "Saiteninstrument"

    def spiele(self):
        print(f"Die {self.name} (ein {self.typ}) spielt ein ruhiges Lied.")

# Erstellen von Objekten
instrument1 = Instrument("Gitarre", "Saiteninstrument")
instrument2 = Instrument("Klavier", "Tasteninstrument")

# Methodenaufrufe zum Testen
instrument1.spiele()   # Ausgabe: Die Gitarre (ein Saiteninstrument) spielt ein ruhiges Lied.
instrument2.spiele()   # Ausgabe: Die Klavier (ein Tasteninstrument) spielt ein ruhiges Lied.
