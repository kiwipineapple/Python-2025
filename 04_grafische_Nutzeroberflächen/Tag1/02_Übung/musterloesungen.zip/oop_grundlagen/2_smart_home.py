# Oberklasse für allgemeine Smart-Home-Geräte
class SmartDevice:
    def __init__(self, name, status="aus"):
        self.name = name           # z.B. "Lampe"
        self.status = status       # z.B. "an" oder "aus"

    def zeige_status(self):
        print(f"{self.name} ist {self.status}.")

# Unterklasse für eine spezielle smarte Lampe
class SmartLampe(SmartDevice):
    def __init__(self, name, status, helligkeit):
        super().__init__(name, status)     # ruft den Konstruktor der Oberklasse auf
        self.helligkeit = helligkeit       # zusätzliches Attribut nur für Lampen

    def zeige_status(self):
        # überschreibt die Methode aus der Oberklasse und nutzt das zusätzliche Attribut
        print(f"{self.name} ist {self.status} mit Helligkeit {self.helligkeit}%.")

# Objekt der Unterklasse erstellen und testen
lampe = SmartLampe("Lampe", "an", 70)
lampe.zeige_status()  # Ausgabe: Lampe ist an mit Helligkeit 70%.
