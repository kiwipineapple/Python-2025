from abc import ABC, abstractmethod


class Tier(ABC):
    @abstractmethod
    def laut(self):
        pass

    @abstractmethod
    def bewegung(self):
        pass


class Hund(Tier):
    def laut(self):
        return "Wau"

    def bewegung(self):
        return "Laufen"


# Test der Implementierung
hund = Hund()
print(f"Der Hund macht: {hund.laut()}")
print(f"Der Hund bewegt sich durch: {hund.bewegung()}")
