from abc import ABC, abstractmethod


class Zahlung(ABC):
    @abstractmethod
    def starte_zahlung(self, betrag):
        pass

    @abstractmethod
    def prüfe_zahlung(self):
        pass


class Kreditkartenzahlung(Zahlung):
    def starte_zahlung(self, betrag):
        print(f"Bearbeite Kreditkartenzahlung von {betrag}")

    def prüfe_zahlung(self):
        print("Überprüfe Kreditkartenzahlung")


class PayPalZahlung(Zahlung):
    def starte_zahlung(self, betrag):
        print(f"Bearbeite PayPal-Zahlung von {betrag}")

    def prüfe_zahlung(self):
        print("Überprüfe PayPal-Zahlung")


# Test der Implementierung
kreditkartenzahlung = Kreditkartenzahlung()
kreditkartenzahlung.starte_zahlung(100)
kreditkartenzahlung.prüfe_zahlung()

paypalzahlung = PayPalZahlung()
paypalzahlung.starte_zahlung(200)
paypalzahlung.prüfe_zahlung()
