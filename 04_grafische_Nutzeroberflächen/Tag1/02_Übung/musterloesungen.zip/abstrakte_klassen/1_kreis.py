from abc import ABC, abstractmethod
import math


class Form(ABC):
    @abstractmethod
    def fläche(self):
        pass


class Kreis(Form):
    def __init__(self, radius):
        self.radius = radius

    def fläche(self):
        return math.pi * self.radius ** 2


# Test der Implementierung
kreis = Kreis(5)
print(f"Die Fläche des Kreises beträgt: {kreis.fläche()}")
