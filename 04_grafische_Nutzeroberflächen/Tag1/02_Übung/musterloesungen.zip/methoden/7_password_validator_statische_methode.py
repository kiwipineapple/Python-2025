class PasswordValidator:
    @staticmethod
    def validate(password):
        if len(password) < 8:
            return False
        has_digit = any(char.isdigit() for char in password)
        has_letter = any(char.isalpha() for char in password)
        return has_digit and has_letter


# Testen Sie die Methode
print(PasswordValidator.validate("pass1234"))  # Ausgabe: True
print(PasswordValidator.validate("shortdfghf"))  # Ausgabe: False
