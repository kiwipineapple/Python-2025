class Employee:
    employee_count = 0

    def __init__(self, name, position):
        self.name = name
        self.position = position
        Employee.employee_count += 1

    def display_employee_info(self):
        return f"Name: {self.name}, Position: {self.position}"

    @classmethod
    def get_employee_count(cls):
        return cls.employee_count

# Testen Sie die Klasse
e1 = Employee("John", "Manager")
e2 = Employee("Jane", "Developer")
print(e1.display_employee_info())  # Ausgabe: Name: John, Position: Manager
print(e2.display_employee_info())  # Ausgabe: Name: Jane, Position: Developer
print(Employee.get_employee_count())  # Ausgabe: 2
