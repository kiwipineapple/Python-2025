class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def birthday(self):
        self.age += 1


# Testen Sie die Klasse
p = Person("Alice", 30)
p.birthday()
print(p.age)  # Ausgabe: 31
