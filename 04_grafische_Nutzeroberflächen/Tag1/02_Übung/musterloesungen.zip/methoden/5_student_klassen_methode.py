class Student:
    school_name = "oberschule"

    @classmethod
    def change_school_name(cls, new_name):
        cls.school_name = new_name


# Testen Sie die Methode
print(Student.school_name)  # Ausgabe: oberschule
Student.change_school_name("realschule")
print(Student.school_name)  # Ausgabe: realschule
