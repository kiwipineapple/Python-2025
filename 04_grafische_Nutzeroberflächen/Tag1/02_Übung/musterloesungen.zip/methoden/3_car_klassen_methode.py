class Car:
    total_cars = 0

    @classmethod
    def increment_total_cars(cls):
        cls.total_cars += 1


# Testen Sie die Methode
Car.increment_total_cars()
Car.increment_total_cars()
print(Car.total_cars)  # Ausgabe: 2
