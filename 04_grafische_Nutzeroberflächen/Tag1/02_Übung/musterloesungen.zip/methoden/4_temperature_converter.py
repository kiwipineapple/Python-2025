class TemperatureConverter:
    @staticmethod
    def celsius_zu_fahrenheit(celsius):
        return (celsius * 9 / 5) + 32

    @staticmethod
    def fahrenheit_zu_celsius(fahrenheit):
        return (fahrenheit - 32) * 5 / 9


# Testen Sie die Methoden
print(TemperatureConverter.celsius_zu_fahrenheit(0))  # Ausgabe: 32.0
print(TemperatureConverter.fahrenheit_zu_celsius(32))  # Ausgabe: 0.0
