class MathOperations:
    @staticmethod
    def is_even(number):
        return number % 2 == 0


# Testen Sie die Methode
print(MathOperations.is_even(4))  # Ausgabe: True
print(MathOperations.is_even(5))  # Ausgabe: False














"""
def is_even(number):
    return number % 2 == 0

user_input = input("geben Sie ein nummer:")
try:
    number = int(user_input)

    if is_even(number):
        print(f" number {number} ist even ")
    else:
         print(f" number {number} ist nicht even")
except ValueError:
     print(f"bitte geben eine richtig nummer")


print(is_even(20))
"""
