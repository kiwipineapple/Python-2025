# Miniprojekt 1: String-Kalkulator mit eigenen Funktionen
# Ziel: Schreibe ein Programm, das mathematische Anweisungen verarbeitet,
# die als Text (string) eingegeben werden.
#   • Rechenausdrücke mit zwei Zahlen und Operator: z. B.  10 + 5 ,  8 * 3, 20 / 4
#   • Mathematische Befehle mit nur einer Zahl:   z. B. Wurzel von 64,
#       Ceil von 3.2,  Betrag von -7
#   • Analysiere die Eingabe und führe die passende Berechnung durch.
#   • Strukturiere dein Programm in mehrere kleine Funktionen,
#     z. B. jeweils eine Funktion für Addition, Wurzelberechnung, Betragsfunktion usw.
#   • Die zentrale Auswertungsfunktion (main bzw. verwalter Funktion)
#     soll erkennen, was gerechnet werden soll, und die passende Rechenfunktion aufrufen

import math


def addition(a, b):
    return a + b


def substraction(a, b):
    return a - b


def mutiplication(a, b):
    return a * b


def division(a, b):
    return a / b


def wurzel(a):
    return a ** 0.5


def ceiling(a):
    return math.ceil(a)


def floor(a):
    return math.floor(a)


def eingabe_auswerten(user_eingabe):
    print(user_eingabe)
    untersuchung = user_eingabe.split()
    print(untersuchung)

    '''if "plus" or "+" in untersuchung:        # nicht funktionierender Code
        print("Hallo")
        a = float(untersuchung[0])
        b = float(untersuchung[2])
        return addition(a, b)'''

    if "plus" in untersuchung or "+" in untersuchung:
        a = float(untersuchung[0])
        b = float(untersuchung[2])
        return addition(a, b)

    elif "minus" in untersuchung or "-" in untersuchung:
        a = float(untersuchung[0])
        b = float(untersuchung[2])
        return substraction(a, b)
    elif "mal" in untersuchung or "*" in untersuchung:
        a = float(untersuchung[0])
        b = float(untersuchung[2])
        return mutiplication(a, b)
    elif "geteilt" in untersuchung or ":" in untersuchung or "/" in untersuchung:
        a = float(untersuchung[0])
        b = float(untersuchung[2])
        return division(a, b)

    elif "wurzel" in untersuchung:
        a = float(untersuchung[1])
        return wurzel(a)

    elif "ceiling" in untersuchung or "aufrunden" in untersuchung:
        a = float(untersuchung[1])
        return ceiling(a)

    elif "floor" in untersuchung or "abrunden" in untersuchung:
        a = float(untersuchung[1])
        return floor(a)
    else:
        return "Unbekannter Fehler"


def taschnrechner():
    print("Willkommen zum simpelsten Taschenrechner der Welt. Bitte beende das Programm mit 'exit'")

    while True:
        user_eingabe = input("Bitte geben sie ihre gewünschte Berechnung ein: ")

        if user_eingabe.lower() == "exit":
            print("Tschöö")
            break

        ergebnis = eingabe_auswerten(user_eingabe)
        print(f"Das Ergebnis beträgt: {ergebnis}")


taschnrechner()


