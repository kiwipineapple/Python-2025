"""
Was macht in?
Der in-Operator prüft, ob ein bestimmter Wert in einem Container
(z.B. Liste, String, Set oder Dictionary) vorhanden ist.

Er liefert immer True oder False zurück.

"""
# Mit einer Liste:
fruechte = ["Apfel", "Banane", "Kirsche"]
#print("Banane" in fruechte)   # True
#print("Traube" in fruechte)   # False

# Mit einem String

text = "Hallo Welt"
#print("Hallo" in text)       # True
#print("H" in text)           # True
#print("Hi" in text)          # False
#print("-" in text)

# Mit einem Dictionary:
info = {"name": "Anna", "alter": 30}
print("name" in info)        # True → sucht NUR in den Schlüsseln
print("name" in info.keys())        # True → sucht NUR in den Schlüsseln
print("Anna" in info)        # False - Anna" ist ein **Wert**, kein **Schlüssel**
print("Anna" in info.values())  # True → explizit in den Werten suchen

