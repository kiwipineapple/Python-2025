# Mit einem Dictionary:
info = {"name": "Anna", "alter": 30}
#print("Anna" in info)        # False - Anna" ist ein **Wert**, kein **Schlüssel**

# Strings
text = "Hallo Welt"
#print("al" in text)   #  True
# Schüler denken oft, dass nur ganze Wörter verglichen werden –
# aber in prüft jeden beliebigen Teilstring.

my_str = "The IS Python code."

"""
print('' in my_str)
print('.' in my_str)
print('e' in my_str)
print('he' in my_str)
print('on' in my_str)
print(' ' in my_str)
print(' Py' in my_str)
print('Py' in my_str)

# True für alles
"""

# regex




# Verschachtelte Listen:
# in prüft nur die oberste Ebene:
zahlen = [  [1, 2], [3, 4] ]
# print(1 in zahlen)  #  False – denn `1` ist nicht direktes Element der Liste

# Richtig:
#print(  any(1 in teil for teil in zahlen  )   )  #  True
# https://www.geeksforgeeks.org/python/python-any-function/

# for teil in zahlen
"""
for teil in zahlen :
    print(teil)
    x = 1 in teil
    print(x)
"""


# combination mit 'or'
frage = ["Empfiehl", "mir", "einen", "Horrorfilm"]

if "Horror" or "Komödie" in frage:
    print("Okay, hier ist eine Empfehlung!")

if "meaw" or False:
    print("hallo")

"""
 # Python interpretiert als :
    # if ("Horror") or ("Komödie" in frage)
    # "Horror" ist ein nicht-leerer String → automatisch True
    # Deshalb wird der Block immer ausgeführt, egal ob "Komödie" in frage ist oder nicht.

# Richtig wäre:  
if "Horror" in frage or "Komödie" in frage:
    print("Okay, hier ist eine Empfehlung!")

oder

if any(genre in frage for genre in ["Horror", "Komödie"]):
    print("Okay, hier ist eine Empfehlung!")


"""
