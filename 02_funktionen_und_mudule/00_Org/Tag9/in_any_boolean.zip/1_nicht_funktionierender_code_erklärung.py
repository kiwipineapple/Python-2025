'''
if "plus" or "+" in untersuchung:        # nicht funktionierender Code
     print("Hallo")
     a = float(untersuchung[0])
     b = float(untersuchung[2])
     return addition(a, b)
'''

"""
Python interpretiert:

if "plus" or "+" in untersuchung:

so wie:

if ("plus") or ("+" in untersuchung):

WICHTIG:
- "plus" ist ein **nicht-leerer String** → wird automatisch als **True** gewertet.
- Daher wird die ganze Bedingung **immer True** 
(weil die erste Bedingung schon True ist – das Ergebnis der zweiten spielt dann keine Rolle)
  
"""
# Beispiel 1 – einfacher Wahrheitswert-Test mit einem nicht-leeren String
if "plus":
    print("Wird ausgeführt")
    # "plus" ist ein nicht-leerer String → wird als True gewertet → Bedingung ist erfüllt

# Beispiel 2 – Kombination mit False
if "plus" or False:  # Angenommen: "+" ist NICHT in untersuchung
    print("Wird ausgeführt")
    # "plus" ist True, False ist egal → gesamte Bedingung ist True → wird ausgeführt

# Beispiel 3 – Kombination mit True
if "plus" or True:  # Angenommen: "+" ist in untersuchung
    print("Wird ausgeführt")
    # "plus" ist wieder True, True sowieso → gesamte Bedingung ist True → wird ausgeführt

# FAZIT:
# Sobald der erste Teil ("plus") True ist, wird der zweite Teil (egal ob True oder False) ignoriert.
# Deshalb funktioniert z.B. `if "plus" or "+" in untersuchung:` NICHT wie erwartet.
