# Thema: Wahrheitswerte (Truthiness) in Python
# In Python kann fast jeder Wert in einen booleschen Wert (True oder False) umgewandelt werden.
# Dies geschieht z.B. automatisch in if-Bedingungen.
# Die Regel lautet:
# -> Ein Wert wird zu True ausgewertet, wenn er "irgendeinen Inhalt" hat.
# -> Leere Werte oder spezielle Werte wie 0, None oder False selbst ergeben False.

print("== Leere oder 'falsy' Werte ==")

# Leerer String ergibt False
print("'' →", bool(''))  # False

# Die Zahl 0 ergibt False
print("0 →", bool(0))  # False

# Die Fließkommazahl 0.0 ergibt False
print("0.0 →", bool(0.0))  # False

# Die komplexe Zahl 0j ergibt False
print("0j →", bool(0j))  # False

# Der spezielle Wert None ergibt False
print("None →", bool(None))  # False

# Eine leere Liste ergibt False
print("[] →", bool([]))  # False

# Ein leeres Tupel ergibt False
print("() →", bool(()))  # False

# Ein leeres Dictionary ergibt False
print("{} →", bool({}))  # False

# Ein leeres Set ergibt False
print("set() →", bool(set()))  # False

# Ein leeres range-Objekt ergibt False
print("range(0) →", bool(range(0)))  # False

print("\n== Nicht-leere oder 'truthy' Werte ==")

# Nicht-leerer String ergibt True
print("'Hallo' →", bool("Hallo"))  # True

# Zahl ungleich 0 ergibt True
print("42 →", bool(42))  # True

# Nicht-leere Liste ergibt True
print("[1, 2, 3] →", bool([1, 2, 3]))  # True

# Nicht-leeres Dictionary ergibt True
print("{'a': 1} →", bool({'a': 1}))  # True

# True ergibt True
print("True →", bool(True))  # True

# False bleibt natürlich False
print("False →", bool(False))  # False


# https://www.geeksforgeeks.org/python/boolean-data-type-in-python/