def begruessung():
    try:
        # Rückgabewert wird vorbereitet: "A" wird gespeichert
        # Aber: Python wartet noch mit der Rückgabe
        return "A"
    except Exception as fehler:
        # Wird nur ausgeführt, wenn im try-Block ein Fehler auftritt
        print("Fehler aufgetreten:", fehler)
    finally:
        # Der finally-Block wird **immer** ausgeführt – auch wenn vorher return oder Fehler kam
        # Wichtig: Dieser Block wird **vor der tatsächlichen Rückgabe** ausgeführt
        print("finally läuft")

# Aufruf der Funktion
print(begruessung())  # Ausgabe:
                   # 1. finally läuft
                   # 2. A
