# ---------------------------------------------
# 🔑 Wie bekomme ich einen API-Key von Cohere?
# ---------------------------------------------
# 1. Gehe zu https://dashboard.cohere.com
# 2. Erstelle kostenlos ein Konto (keine Kreditkarte nötig!)
# 3. Gehe im Dashboard auf "API Keys"
# 4. Kopiere den angezeigten Schlüssel (sieht aus wie: "xyz...123")
# 5. Speichere ihn sicher in einer separaten Datei namens z.B my_keys.py:
#
#     # my_keys.py
#     coherent_key = "dein-echter-api-key-hier"
#
# ❗ Wichtig: Lade diese Datei niemals öffentlich hoch!
# ---------------------------------------------

# Importiert die Cohere-Bibliothek für KI-Anfragen
# Installiere sie ggf. zuerst mit: pip install cohere
import cohere

# Importiert deinen geheimen API-Schlüssel aus einer separaten Datei
# Diese Datei enthält z.B.: coherent_key = "dein-api-key"
# Damit bleibt dein Schlüssel aus dem Hauptcode heraus – sicher & sauber.
import my_keys

# Erstellt ein Client-Objekt mit deinem API-Key, um mit der Cohere-API zu kommunizieren
co = cohere.Client(my_keys.coherent_key)

# Sendet eine einfache Chat-Nachricht an das KI-Modell
# Die KI antwortet darauf wie bei einem echten Dialog
response = co.chat(
    message="was ist 50 plus sieben"
)

# Gibt die Antwort der KI aus
# Hier z.B.: "The answer is 18."
print(response.text)

# Schreibe einen Dialog zwischen einer Katze und einem Staubsauger, die über den Sinn des Lebens diskutieren.
# Erfinde eine neue Superkraft, die völlig nutzlos, aber extrem beeindruckend klingt.
# Schreibe ein Bewerbungsschreiben von einem Tintenfisch, der sich für einen Bürojob bewirbt.
