"""
KI-Einbindung in Python bedeutet, vortrainierte KI-Modelle zu nutzen,
um z.B. Texte zu analysieren oder zu generieren.

Dies ist möglich über Bibliotheken wie `transformers` (offline) oder Cloud-Dienste wie OpenAI oder Cohere (mit API).

    Mit `transformers.pipeline` können lokal gespeicherte Modelle direkt verwendet werden – z.B. zur Sentiment-Analyse.

    Bei API-basierten Lösungen wird die Anfrage an einen Server gesendet, der die KI ausführt und eine Antwort
    zurückgibt.Cohere bietet z.B. ein freies Textgenerierungsmodell, bei dem ein Prompt (Frage) zu einer passenden Antwort führt.

Beide Varianten zeigen, wie Python mit wenigen Zeilen Zugang zu moderner KI bietet – ganz ohne eigenes Training.

Solche Lösungen eignen sich hervorragend für Chatbots, Textanalyse, Kreativanwendungen oder erste KI-Projekte.

Die Auswahl hängt davon ab, ob man online arbeitet (API) oder lieber lokal (offline) ohne Schlüssel experimentiert.
"""


"""
Einige Python-Bibliotheken für KI:
transformers (von Hugging Face) – für Sprachmodelle (z.B. GPT, BERT) in NLP-Anwendungen wie 
Textgenerierung, Sentiment-Analyse, Fragebeantwortung etc.

scikit-learn – für klassische Machine Learning Modelle wie Entscheidungsbäume, SVMs, 
KNN, Clustering. Gut für strukturierte Daten.

tensorflow / keras – für Deep Learning und neuronale Netze. keras ist eine High-Level-API,
 die oft mit tensorflow genutzt wird.

torch / pytorch – alternative Deep-Learning-Bibliothek zu TensorFlow. Sehr beliebt in 
der Forschung und bei vielen modernen KI-Modellen (auch Hugging Face nutzt PyTorch als Backend).

openai – offizielle Python-Bibliothek zur Nutzung der OpenAI-Modelle (wie GPT-4, DALL·E etc.)
 per API. API-Key erforderlich.

cv2 (OpenCV) – für Bildverarbeitung, Objektverfolgung, Kantenerkennung, 
Bilderkennung (vorverarbeitend für KI).
"""
