"""
Hugging Face ist ein Unternehmen aus Frankreich, das sich auf künstliche Intelligenz (KI)
spezialisiert hat – besonders auf den Bereich Sprachverarbeitung (NLP).

Es bietet eine riesige Bibliothek mit vortrainierten KI-Modellen, die jeder nutzen kann – kostenlos!

https://huggingface.co/

Hugging Face = Das "GitHub für KI-Modelle" – offen, kostenlos, gemeinschaftlich
"""

"""
Was ist das transformers-Modul?
    transformers ist eine Python-Bibliothek von Hugging Face, mit der du fertige KI-Modelle sehr
    einfach nutzen kannst – z.B. für:
        Textklassifikation (z.B. positive/negative Bewertung)
        Textgenerierung (wie ChatGPT)  
        Übersetzungen   
        Frage-Antwort-Systeme    
        (teilweise auch Audio und Bilder)
    
    https://huggingface.co/docs/transformers/main/en/task_summary
    https://github.com/huggingface/transformers
    https://huggingface.co/models
"""

"""
Was macht pipeline()?
    pipeline() ist eine Hilfsfunktion aus dem Modul transformers. 
    Sie macht es dir sehr einfach, ein Modell zu benutzen – ohne viele Details wissen zu müssen.
    
    Du gibst nur an, was du machen willst, z.B.:
        pipeline("sentiment-analysis")      # Stimmung erkennen
        pipeline("text-generation")         # Text automatisch weiter schreiben
        pipeline("translation_de_to_en")    # Übersetzen von Deutsch nach Englisch
        
        Das Modell wird automatisch heruntergeladen (einmalig)
        Es wird geladen
        Dein Text wird durch das Modell geschickt
        Das Ergebnis kommt direkt zurück
            
        Wenn du z.B. schreibst:
        from transformers import pipeline
        classifier = pipeline("sentiment-analysis")
        
        …dann passiert Folgendes:
    
            pipeline() erkennt, dass du eine Stimmungsklassifikation willst.
            
            Es lädt ein passendes Modell von der Hugging Face-Website herunter 
            (z.B. distilbert-base-uncased-finetuned-sst-2-english)
            
            Das Modell wird lokal auf deinem Computer gespeichert (Standardpfad: z.B. ~/.cache/huggingface/)
            
            Danach wird es direkt verwendet, und beim nächsten Mal nicht nochmal heruntergeladen.

    Warum braucht transformers auch torch?
    
        Damit die Bibliothek transformers bzw. pipeline() richtig funktioniert, benötigen wir zusätzlich torch – 
        denn ohne diese Rechenbasis kann das Modell nicht arbeiten.
        
        torch ist eine leistungsstarke Rechenbibliothek für numerische Berechnungen und wird vor allem 
        im Bereich künstliche Intelligenz und Deep Learning verwendet.
        
        Sie dient als Motor, der dafür sorgt, dass KI-Modelle überhaupt rechnen können – 
        sowohl auf der CPU als auch auf der GPU.
        
        Wenn du mit transformers arbeitest, nutzt es torch, um Texte in Zahlen umzuwandeln, neuronale Netze zu durchlaufen und 
        Vorhersagen zu berechnen.
        
        https://en.wikipedia.org/wiki/Torch_(machine_learning)
        https://pytorch.org/
        
    
"""


"""
Bekannte Modelle auf Hugging Face

    | Modellname                         | Wofür gedacht                          | Beschreibung                        |
    | ---------------------------------- | -------------------------------------- | ----------------------------------- |
    | `bert-base-uncased`                | Textklassifikation                     | Klassiker, versteht Sprache gut     |
    | `distilbert-base-uncased`          | Leichtgewicht von BERT                 | Schneller, kleiner, trotzdem gut    |
    | `gpt2`                             | Textgenerierung                        | Schreibt Geschichten, Artikel, etc. |
    | `t5-small`                         | Übersetzungen, Zusammenfassungen, etc. | Multitool für NLP                   |
    | `facebook/bart-large-cnn`          | Textzusammenfassungen                  | Macht aus langen Texten kurze       |
    | `oliverguhr/german-sentiment-bert` | Stimmung für **deutsche Texte**        | Super für Deutsch-Unterricht!       |
    
    
    https://huggingface.co/models
    
    Dort kannst du:
    
    Nach Anwendungsbereich filtern (Textklassifikation, Übersetzung, etc.)
    Nach Sprache filtern (z.B. Deutsch)
    Nach Modellname suchen (z.B. gpt2, bert, whisper, etc.)
    die Modelle testen, dir passenden Python-Code generieren lassen, sie herunterladen – 
    oder sie einfach mit pipeline() automatisch laden, wenn du sie brauchst.


"""