from transformers import pipeline

# Hinweis: Vor der ersten Nutzung müssen folgende Pakete installiert sein:
# pip install transformers
# pip install torch

# Erstellt ein Sentiment-Analyse-Modell (z.B. erkennt positive oder negative Stimmung)
# Das benötigte Modell wird automatisch beim ersten Start heruntergeladen und lokal gespeichert.
# Es erfolgt KEIN Live-API-Aufruf – alles läuft lokal auf dem eigenen Rechner.

classifier = pipeline("sentiment-analysis")  # Aufgabe definieren (Stimmungsanalyse)
# Hinweis: Manche IDEs (z.B. PyCharm) zeigen hier eine Warnung an – diese kann ignoriert werden.
# Der Task "sentiment-analysis" ist technisch korrekt und wird intern als "text-classification" verarbeitet.

# Analysiert die Stimmung des eingegebenen Textes
result = classifier("You are amazing, idiot")

# Gibt das Ergebnis zurück – z.B. POSITIVE oder NEGATIVE mit einer Wahrscheinlichkeit
print(result)




"""
classifier = pipeline(task="text-classification", model="distilbert-base-uncased-finetuned-sst-2-english")
# Gleiches Ergebnis wie bei "sentiment-analysis", aber explizit definiert.
"""


"""
# Alternativer Aufruf mit mehreren Texten auf einmal
texts = ["You are amazing", "This is terrible"]

# Übergibt die Liste an das Modell zur Stimmungserkennung
result = classifier(texts)  # Liste von Texten analysieren

# Gibt das Ergebnis für jeden Text einzeln aus
for r in result:
    print(r)

"""

