from transformers import pipeline

# Lädt ein vortrainiertes Sentiment-Analyse-Modell für deutsche Texte
# Modellquelle: https://huggingface.co/oliverguhr/german-sentiment-bert
# Gibt sowohl die Stimmung (POSITIVE/NEGATIVE/NEUTRAL) als auch einen Score (Wahrscheinlichkeit) zurück

classifier = pipeline("sentiment-analysis", model="oliverguhr/german-sentiment-bert")
# Hinweis: Manche IDEs (z.B. PyCharm) zeigen hier eine Warnung an – diese kann ignoriert werden.

# Beispieltext auf Deutsch
result = classifier("Ich bin König")

print(result)

"""
🔄 Alternativer Zugang:
- Das gleiche Modell ist auch als fertiges Python-Paket verfügbar:
  → pip install germansentiment
  → from germansentiment import SentimentModel
- Vorteil: Noch einfachere Nutzung ohne Hugging Face pipeline()
"""
