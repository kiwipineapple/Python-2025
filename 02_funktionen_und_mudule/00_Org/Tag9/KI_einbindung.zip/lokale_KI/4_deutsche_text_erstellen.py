from transformers import pipeline

# Lädt ein vortrainiertes Sprachmodell für deutsche Texte (german-gpt2)
# Das Modell wurde mit deutschen Wikipedia- und Nachrichtentexten trainiert
# Es eignet sich gut für flüssige und grammatikalisch richtige deutsche Sätze

# Weitere Einstellmöglichkeiten für Textgenerierung findest du unter:
# https://huggingface.co/docs/transformers/main/en/main_classes/text_generation
generator = pipeline("text-generation", model="dbmdz/german-gpt2")

# Vorgabetext (Prompt) für eine lustige Schulgeschichte
prompt = (
    "Es war der erste Montag nach den Ferien. Der Lehrer betrat das Klassenzimmer und wollte gerade etwas an die Tafel schreiben, "
    "als die Kreide plötzlich laut rief: „Nicht schon wieder! Ich habe genug von deinen Matheformeln!“ "
    "Die Schüler starrten ungläubig, und der Lehrer ließ die Kreide fallen. "
    "Dann ertönte eine zweite Stimme – diesmal von der Tafel:"
)




# Das Modell schreibt den Text bis zu 50 Tokens weiter
result = generator(prompt, max_length=50, num_return_sequences=1)

# Gibt den erzeugten deutschen Text auf dem Bildschirm aus
print(result[0]["generated_text"])


