# Importiert das Pipeline-Modul aus der Transformers-Bibliothek
# Mit pipeline lassen sich vortrainierte KI-Modelle einfach nutzen
from transformers import pipeline

# WICHTIG: Stelle sicher, dass die Bibliothek 'Pillow' installiert ist – notwendig für die Bildverarbeitung
# Installation im Terminal: pip install Pillow

# Lädt ein vortrainiertes Bildklassifikationsmodell
# Dieses Modell erkennt, was auf einem Bild zu sehen ist (z.B. Katze, Hund, Auto ...)
classifier = pipeline("image-classification")

# Übergibt ein Beispielbild (Katze) über einen direkten Bild-Link
# Der Link muss direkt auf eine Bilddatei (z.B. .png, .jpg) zeigen
# result = classifier("https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/cats.png")
result = classifier("https://cdn.pixabay.com/photo/2016/02/28/12/55/boy-1226964_1280.jpg")

# Bilder links zum testen : https://pixabay.com/images/search/link/


# Gibt das Ergebnis als Liste von erkannten Objekten mit Wahrscheinlichkeiten aus
# Beispielausgabe: [{'label': 'tabby, tabby cat', 'score': 0.98}, ...]
print(result)
