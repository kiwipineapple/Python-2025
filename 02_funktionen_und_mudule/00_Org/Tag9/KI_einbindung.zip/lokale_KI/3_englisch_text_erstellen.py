from transformers import pipeline

# Lädt ein vortrainiertes Sprachmodell für englische Texte (GPT-2)
# Dieses Modell wurde mit großen englischen Textmengen trainiert (z.B. Wikipedia, Bücher)
# Es kann einen Satzanfang kreativ und flüssig fortsetzen
# Weitere Einstellmöglichkeiten für Textgenerierung findest du unter:
# https://huggingface.co/docs/transformers/main/en/main_classes/text_generation
generator = pipeline("text-generation", model="gpt2")

# Vorgabetext (Prompt) auf Englisch
prompt = (
    "I am hungry. I walked into the kitchen and opened the fridge. "
    "There was a strange light coming from inside, and something smelled unusual. "
    "I leaned in to take a closer look, and suddenly i couldn’t believe what I saw..."
)

# Text wird bis zu 50 Tokens (Wörter + Satzzeichen) weitergeschrieben
# num_return_sequences=1 → es wird nur eine Version erzeugt
result = generator(prompt, max_length=50, num_return_sequences=1)

#print(result)

# Gibt den erzeugten Text sauber mit Trennlinie aus
generated_text = result[0]["generated_text"]

print(generated_text)


