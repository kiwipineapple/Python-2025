"""
In Python gibt and nicht einfach True oder False zurück, sondern einen der beiden Werte selbst.

--> Gibt den ersten falsy Wert zurück (wenn vorhanden)
--> Gibt den letzten Wert zurück, wenn alle truthy sind
"""

print("== and-Operator in Python – Zusatzbeispiele ==")

# Beispiel 1: Leere Liste und nicht-leere Liste
print([] and [1, 2, 3])
# [] ist falsy → and gibt den ersten falsy-Wert zurück → []

# Beispiel 2: Nicht-leere Liste und leere Liste
print([1, 2, 3] and [])
# [1, 2, 3] ist truthy → and prüft weiter und gibt zweiten Wert zurück → []

# Beispiel 3: Zwei truthy-Listen
print([1, 2] and [3, 4])
# Beide sind truthy → and gibt den zweiten Wert zurück → [3, 4]

# Beispiel 4: 0 and String
print(0 and "Hallo")
# 0 ist falsy → and bricht ab und gibt 0 zurück

# Beispiel 5: String and 0
print("Hi" and 0)
# "Hi" ist truthy → and prüft weiter → gibt 0 zurück

# Beispiel 6: Mehrere and-Verknüpfungen
print(1 and 2 and 3)
# Alle sind truthy → and gibt den letzten Wert zurück → 3

# Beispiel 7: Leerer String und Alternativwert
print("" and "Fallback")
# "" ist falsy → and gibt "" zurück

# Beispiel 8: False and True
print(False and True)  # False – weil False der erste falsy Wert ist

# Zu Beispiel 8:
# So funktioniert 'and' bei Booleans –
# bei anderen Datentypen ist es dasselbe Prinzip mit anderen Werten.




