"""
Auch or gibt nicht einfach True oder False zurück, sondern einen der beiden Operanden selbst.
Dabei gilt:

-> Gibt den ersten truthy Wert zurück (wenn vorhanden)
-> Gibt den letzten Wert zurück, wenn alle falsy sind
"""

print("== or-Operator in Python – Zusatzbeispiele ==")

# Beispiel 1: Leere Liste oder nicht-leere Liste
print([] or [1, 2, 3])
# [] ist falsy → or gibt den zweiten Wert zurück → [1, 2, 3]

# Beispiel 2: Nicht-leere Liste oder leere Liste
print([1, 2, 3] or [])
# Erste Liste ist truthy → or gibt sie direkt zurück → [1, 2, 3]

# Beispiel 3: Zwei truthy-Listen
print([1, 2] or [3, 4])
# Erste ist truthy → or gibt sie zurück → [1, 2]

# Beispiel 4: 0 or String
print(0 or "Hallo")
# 0 ist falsy → or gibt zweiten Wert zurück → "Hallo"

# Beispiel 5: String or 0
print("Hi" or 0)
# "Hi" ist truthy → or gibt ersten Wert zurück → "Hi"

# Beispiel 6: Mehrere or-Verknüpfungen
print(0 or False or "Ja")
# 0 → falsy, False → falsy, "Ja" → truthy → gibt "Ja" zurück

# Beispiel 7: Leerer String oder Alternativwert
print("" or "Fallback")
# "" ist falsy → or gibt "Fallback" zurück

# Beispiel 8: False or True
print(False or True)  # True – weil True der erste truthy Wert ist

# Zu Beispiel 8:
# So läuft's bei 'or' mit Booleans –
# bei Listen, Strings oder Zahlen passiert im Grunde dasselbe.



