# Lösung:
class UngueltigerBereichError(Exception):
    def __init__(self, wert, nachricht="Wert liegt außerhalb des gültigen Bereichs"):
        self.wert = wert
        self.nachricht = nachricht
        super().__init__(f"{nachricht}: Gegebene wert = {wert}")

def pruefe_bereich(wert, minimum, maximum):
    if wert < minimum or wert > maximum:
        raise UngueltigerBereichError(wert,  f"Wert liegt nicht im Bereich {minimum}–{maximum}")

try:
    wert = int(input("Geben Sie eine Zahl ein: "))
    pruefe_bereich(wert, 1, 10)
    print("Wert liegt im gültigen Bereich.")
except UngueltigerBereichError as e:
    print(f"Fehler : {type(e).__name__} - {e}")
