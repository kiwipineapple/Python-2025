def check_alter(alter):
    if alter < 0:
        raise ValueError(f"Alter ({alter}) darf nicht negativ sein.")
    elif alter > 130:
        raise ValueError(f"Alter ({alter}) scheint ungültig – realistisches Maximum: 130.")
    print("Alter akzeptiert:", alter)

try:
    check_alter(25)  # Gültiger Fall
    check_alter(131)  # Ungültiger Fall
    check_alter(-5)  # Ungültiger Fall

except ValueError as e:
    print("Fehler:", e)
