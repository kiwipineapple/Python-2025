class NichtGenugGeld(Exception):
    def __init__(self, betrag, guthaben):
        self.betrag = betrag
        self.guthaben = guthaben
        super().__init__(f"{betrag}€ gewünscht, aber nur {guthaben}€ verfügbar.")

def abheben(betrag, guthaben):
    if betrag > guthaben:
        raise NichtGenugGeld(betrag, guthaben)
    return guthaben - betrag

try:
    rest = abheben(100, 20)
    print("Neues Guthaben:", rest)
except NichtGenugGeld as fehler:
    print("Fehler:", fehler)
