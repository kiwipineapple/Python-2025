class UngueltigerRabatt(Exception):
    def __init__(self, rabatt, maximal):
        self.rabatt = rabatt
        self.maximal = maximal
        super().__init__(f"Rabatt von {rabatt}% ist zu hoch. Maximal erlaubt: {maximal}%.")

def rabatt_pruefen(rabatt):
    if rabatt > 50:
        raise UngueltigerRabatt(rabatt, 50)
    print(f"Rabatt von {rabatt}% wurde akzeptiert.")

try:
    rabatt_pruefen(50)
    rabatt_pruefen(30)
    rabatt_pruefen(60)
except UngueltigerRabatt as fehler:
    print("Fehler:", fehler)
