class ZuKurz(Exception):
    def __init__(self, laenge):
        super().__init__(f"Passwort ist zu kurz ({laenge} Zeichen). Mindestens 8 nötig.")

class KeineZahl(Exception):
    def __init__(self):
        super().__init__("Passwort enthält keine Zahl.")

class KeinGrossbuchstabe(Exception):
    def __init__(self):
        super().__init__("Passwort enthält keinen Großbuchstaben.")

def check_passwort(pw):
    if len(pw) < 8:
        raise ZuKurz(len(pw))
    if not any(char.isdigit() for char in pw):
        raise KeineZahl()
    if not any(char.isupper() for char in pw):
        raise KeinGrossbuchstabe()
    print("Passwort akzeptiert.")

try:
    check_passwort("aAbcde1")
except Exception as fehler:
    print("Fehler:", fehler)
