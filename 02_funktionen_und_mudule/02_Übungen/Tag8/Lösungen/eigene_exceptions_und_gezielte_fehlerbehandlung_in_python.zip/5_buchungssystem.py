class ZuVielePlaetzeGebucht(Exception):
    def __init__(self, angefragt, verfuegbar):
        self.angefragt = angefragt
        self.verfuegbar = verfuegbar
        super().__init__(f"{angefragt} Plätze angefragt, aber nur {verfuegbar} verfügbar.")

def buchen(anzahl, verfuegbar):
    if anzahl > verfuegbar:
        raise ZuVielePlaetzeGebucht(anzahl, verfuegbar)
    print(f"{anzahl} Plätze erfolgreich gebucht.")

try:
    buchen(3, 5)
    buchen(6, 5)
except ZuVielePlaetzeGebucht as e:
    print("Fehler:", e)
