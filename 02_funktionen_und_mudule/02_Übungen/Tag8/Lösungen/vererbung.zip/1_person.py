class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age


class Student(Person):
    def __init__(self, name, age, student_id):
        super().__init__(name, age)
        self.student_id = student_id


# Testen
p = Person("Alice", 30)
s = Student("Bob", 20, "S12345")

print(f"Person: {p.name}, {p.age}")
print(f"Student: {s.name}, {s.age}, {s.student_id}")
