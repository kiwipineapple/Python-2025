class Employee:
    def __init__(self, name):
        self.name = name

    def get_role(self):
        return f"{self.name} hat eine allgemeine Mitarbeiterrolle."


class Manager(Employee):
    def get_role(self):
        return f"{self.name}  ist ein Manager, der die Teamarbeit überwacht."


class Developer(Employee):
    def get_role(self):
        return f"{self.name} ist ein Entwickler, der Code schreibt und wartet."


# Testen
employee = Employee("Alex")
manager = Manager("Bob")
developer = Developer("Carol")

print(employee.get_role()) # Ausgabe: Alex hat eine allgemeine Mitarbeiterrolle.
print(manager.get_role())  # Ausgabe: Bob ist ein Manager, der die Teamarbeit überwacht.
print(developer.get_role())  # Ausgabe: Carol ist ein Entwickler, der Code schreibt und wartet.
