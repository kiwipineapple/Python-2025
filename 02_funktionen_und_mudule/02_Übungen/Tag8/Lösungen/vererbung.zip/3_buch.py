class Buch:
    def __init__(self, titel, autor):
        self.titel = titel
        self.autor = autor

    def get_info(self):
        return f"Buch: {self.titel} von {self.autor}"


class Ebook(Buch):
    def __init__(self, titel, autor, dateigroesse):
        super().__init__(titel, autor)
        self.dateigroesse = dateigroesse

    def get_info(self):
        return f"Ebook: {self.titel} von {self.autor}, Dateigröße: {self.dateigroesse}MB"


# Testen
buch = Buch("1984", "George Orwell")
ebook = Ebook("Digital Fortress", "Dan Brown", 2)

print(buch.get_info())  # Ausgabe: Buch: 1984 von George Orwell
print(ebook.get_info())  # Ausgabe: Ebook: Digital Fortress von Dan Brown, Dateigröße: 2MB
