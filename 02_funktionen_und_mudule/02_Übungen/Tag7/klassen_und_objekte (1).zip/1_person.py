class Person:
    def __init__(self, name, alter):
        # Initialisiert die Attribute name und alter mit den übergebenen Werten
        self.name = name
        self.alter = alter

    def vorstellen(self):
        # Gibt eine Vorstellung der Person aus
        print(f"Hallo, mein Name ist {self.name} und ich bin {self.alter} Jahre alt.")


# Erstellen eines Objekts der Klasse Person
person1 = Person("Anna", 30)
person1.vorstellen()  # Ausgabe: Hallo, mein Name ist Anna und ich bin 30 Jahre alt.
