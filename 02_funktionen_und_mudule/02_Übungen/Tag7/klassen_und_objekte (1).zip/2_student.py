class Student:
    def __init__(self, name, matrikelnummer):
        # Initialisiert die Attribute name und matrikelnummer und eine leere Liste für noten
        self.name = name
        self.matrikelnummer = matrikelnummer
        self.noten = []

    def add_note(self, note):
        # Fügt eine Note zur Liste der noten hinzu
        self.noten.append(note)

    def durchschnittsnote(self):
        # Berechnet und gibt die Durchschnittsnote zurück
        if len(self.noten) > 0:
            return sum(self.noten) / len(self.noten)
        else:
            return 0


# Erstellen eines Objekts der Klasse Student
student1 = Student("Max", "123456")
student1.add_note(1.7)
student1.add_note(2.3)
student1.add_note(1.0)
print(f"Durchschnittsnote: {student1.durchschnittsnote()}")  # Ausgabe: Durchschnittsnote: 1.6666666666666667
