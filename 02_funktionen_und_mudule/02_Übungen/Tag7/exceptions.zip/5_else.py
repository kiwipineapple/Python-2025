# Lösung:
try:
    zahl1 = int(input("Geben Sie die erste Zahl ein: "))
    zahl2 = int(input("Geben Sie die zweite Zahl ein: "))
    ergebnis = zahl1 / zahl2
except ZeroDivisionError:
    print("Fehler: Division durch Null ist nicht erlaubt.")
except ValueError:
    print("Fehler: Ungültige Eingabe. Bitte geben Sie eine Zahl ein.")
else:
    print(f"Das Ergebnis ist: {ergebnis}")  # Dieser Block wird nur ausgeführt, wenn keine Exception auftritt
