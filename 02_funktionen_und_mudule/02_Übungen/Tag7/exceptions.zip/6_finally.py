# Lösung:
try:
    file = open('datei.txt', 'r')
    inhalt = file.read()
    print(inhalt)
except FileNotFoundError:
    print("Fehler: Die Datei wurde nicht gefunden.")
finally:
    # file.close()
    print("Datei wurde geschlossen.")  # Dieser Block wird immer ausgeführt
