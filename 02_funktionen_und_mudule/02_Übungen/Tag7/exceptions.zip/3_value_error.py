# Lösung:
try:
    zahl = int(input("Geben Sie eine Zahl ein: "))
    print(f"Sie haben die Zahl {zahl} eingegeben.")
except ValueError:
    print("Fehler: Ungültige Eingabe. Bitte geben Sie eine Zahl ein.")
