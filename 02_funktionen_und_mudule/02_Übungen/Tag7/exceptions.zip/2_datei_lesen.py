# Lösung:
try:
    with open('datei.txt', 'r') as file:
        inhalt = file.read()
        print(inhalt)
except FileNotFoundError:
    print("Fehler: Die Datei wurde nicht gefunden.")
