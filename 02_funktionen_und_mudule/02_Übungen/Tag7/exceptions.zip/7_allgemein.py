# Lösung:
try:
    file = open('../meine_datei.txt', 'r')
    inhalt = file.read()
    print(inhalt)
    #print(inhalt.splitlines())
    zahlen = [int(zeile) for zeile in inhalt.splitlines()]

    durchschnitt = sum(zahlen) / len(zahlen)
    print(f"Durchschnitt: {durchschnitt}")
except Exception as e:
    print(f"Ein Fehler ist aufgetreten: {type(e).__name__} : {e}")
finally:
    try:
        file.close()
    except Exception:
        print("Fehler beim Schließen der Datei.")
