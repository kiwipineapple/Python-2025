# Lösung:
try:
    zahl1 = int(input("Geben Sie die erste Zahl ein: "))
    zahl2 = int(input("Geben Sie die zweite Zahl ein: "))
    ergebnis = zahl1 / zahl2
    print(f"Das Ergebnis ist: {ergebnis}")
except ZeroDivisionError:
    print("Fehler: Division durch Null ist nicht erlaubt.")
except ValueError:
    print("Fehler: Ungültige Eingabe. Bitte geben Sie eine Zahl ein.")
