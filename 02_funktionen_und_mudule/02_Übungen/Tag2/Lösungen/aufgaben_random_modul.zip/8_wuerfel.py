import random

# Zähler für jede Augenzahl
zaehler = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0}

# 100-mal würfeln
for _ in range(100):
    wurf = random.randint(1, 6)
    zaehler[wurf] += 1


# Ergebnis ausgeben
for augenzahl in range(1, 7):
    print(f"{augenzahl} wurde {zaehler[augenzahl]}-mal geworfen")

print(zaehler) #zum testen

"""
# Alternative Lösung mit Liste 
 
# Erstelle eine Liste mit 6 Zählern für die Augenzahlen 1 bis 6
wuerfe = [0] * 6
# Das ist gleich wie: wuerfe = [0, 0, 0, 0, 0, 0]


# Simuliere 100 Würfe
for i in range(100):
    wurf = random.randint(1, 6)  # Zufallszahl zwischen 1 und 6
    wuerfe[wurf - 1] += 1        # Erhöhe den entsprechenden Zähler

# Gib die Ergebnisse aus
for i in range(6):
    print(f"{i+1} wurde {wuerfe[i]}-mal geworfen")
"""





"""
# Alternative Lösung mit match - Gut zum Üben von match	- Aber diese Lösung ist Länger, weniger flexibel

# Zähler vorbereiten
eins = zwei = drei = vier = fuenf = sechs = 0

# 100-mal würfeln
for _ in range(100):
    wurf = random.randint(1, 6)

    match wurf:
        case 1:
            eins += 1
        case 2:
            zwei += 1
        case 3:
            drei += 1
        case 4:
            vier += 1
        case 5:
            fuenf += 1
        case 6:
            sechs += 1

# Ergebnisse anzeigen
print(f"1 wurde {eins}-mal geworfen")
print(f"2 wurde {zwei}-mal geworfen")
print(f"3 wurde {drei}-mal geworfen")
print(f"4 wurde {vier}-mal geworfen")
print(f"5 wurde {fuenf}-mal geworfen")
print(f"6 wurde {sechs}-mal geworfen")
"""