import random

zahlen = [10, 20, 30, 40]
random.shuffle(zahlen)
print(zahlen)
