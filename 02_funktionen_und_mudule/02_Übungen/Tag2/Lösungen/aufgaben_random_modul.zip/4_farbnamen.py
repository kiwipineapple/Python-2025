import random

farben = ["rot", "grün", "blau", "gelb"]
for i in range(3):
    print(random.choice(farben))
