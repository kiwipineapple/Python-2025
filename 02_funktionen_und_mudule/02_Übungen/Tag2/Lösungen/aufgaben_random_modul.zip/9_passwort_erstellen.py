import random
import string

# Erstelle eine Liste von Zeichen:
# string.ascii_letters enthält alle Buchstaben (a-z und A-Z)
# string.digits enthält die Ziffern 0 bis 9
zeichen = string.ascii_letters + string.digits
# Das ist gleich wie:  zeichen = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


# Leere Zeichenkette, in die wir das Passwort aufbauen
passwort = ""

# Schleife läuft 8-mal, um 8 Zeichen auszuwählen
for i in range(8):
    passwort += random.choice(zeichen)  # Wähle ein zufälliges Zeichen aus der Liste

# Gib das fertige Passwort aus
print("Passwort:", passwort)






# Alternative 1 (leicht fortgeschritten): Generator-Expression
# Hier werden 8 zufällige Zeichen ausgewählt – Zeichen können mehrfach vorkommen.
# passwort1 = ''.join(random.choice(zeichen) for _ in range(8))


# Alternative 2: Auswahl ohne Wiederholungen – jedes Zeichen kommt höchstens einmal vor
# random.sample() wählt 8 verschiedene Zeichen aus der Liste
# passwort2 = ''.join(random.sample(zeichen,8))

# Alternative 3
# Erzeuge ein Passwort mit random.choices() – Zeichen können sich wiederholen
# passwort3 = ''.join(random.choices(zeichen, k=8))





