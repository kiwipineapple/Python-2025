import random

fruechte = ["Apfel", "Banane", "Kirsche", "Orange"]
auswahl = random.sample(fruechte, 2)
print(auswahl)


# print(random.choice(fruechte))
