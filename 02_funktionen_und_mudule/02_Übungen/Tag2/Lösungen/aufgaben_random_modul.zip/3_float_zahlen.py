import random

for i in range(3):
    print(random.uniform(1.5, 3.5))
