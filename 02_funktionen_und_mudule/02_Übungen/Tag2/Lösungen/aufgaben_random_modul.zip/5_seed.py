import random

random.seed(123)
print(random.randint(1, 100))
random.seed(123)
print(random.randint(1, 100))  # sollte identisch sein
