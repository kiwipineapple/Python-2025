import random

# Schritt 1: Tipps vom Benutzer einholen
benutzer_tipp = []

print("Bitte geben Sie 6 verschiedene Lottozahlen ein (zwischen 1 und 49):")

while len(benutzer_tipp) < 6:
    eingabe = input(f"Zahl {len(benutzer_tipp) + 1}: ")

    # Überprüfen, ob die Eingabe eine ganze positive Zahl ist
    if not eingabe.isdigit():
        print("Bitte geben Sie eine positive ganze Zahl ein.")
        continue

    zahl = int(eingabe)

    # Prüfen, ob die Zahl im gültigen Bereich liegt
    if zahl < 1 or zahl > 49:
        print("Die Zahl muss zwischen 1 und 49 liegen.")
        continue

    # Prüfen, ob die Zahl bereits eingegeben wurde
    if zahl in benutzer_tipp:
        print("Diese Zahl haben Sie bereits eingegeben.")
        continue

    # Die Zahl ist gültig → zur Liste hinzufügen
    benutzer_tipp.append(zahl)

# Schritt 2: Lottozahlen ziehen (6 aus 49, ohne Wiederholung)
lottozahlen = random.sample(range(1, 50), 6)
lottozahlen.sort()  # Aufsteigend sortieren

# Schritt 3: Superzahl ziehen (Zahl zwischen 0 und 9)
superzahl = random.randint(0, 9)

# Schritt 4: Treffer ermitteln
treffer = []
for zahl in benutzer_tipp:
    if zahl in lottozahlen:
        treffer.append(zahl)

# Schritt 5: Ergebnisse anzeigen
print("\nGezogene Lottozahlen: ", lottozahlen)
print("Superzahl:             ", superzahl)
print("Ihre Tipps:           ", benutzer_tipp)
print(f"\nSie haben {len(treffer)} Richtige!")

if treffer:
    print("Getroffene Zahlen:     ", treffer)
