text = "a1b2c3d4"
zahlen = [int(char) for char in text if char.isdigit()]
print(zahlen)