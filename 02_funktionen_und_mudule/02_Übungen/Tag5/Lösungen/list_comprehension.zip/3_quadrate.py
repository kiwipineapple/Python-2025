quadrate = [x**2 for x in range(11)]
print(quadrate)