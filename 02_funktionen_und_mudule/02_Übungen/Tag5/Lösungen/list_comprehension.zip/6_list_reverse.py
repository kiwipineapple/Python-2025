städte = ["Berlin", "München", "Hamburg", "Köln"]

# Umkehren der Liste
städte.reverse()

# Umwandeln der Städtenamen in Großbuchstaben
großbuchstaben_städte = [stadt.upper() for stadt in städte]

print(großbuchstaben_städte)