words = ["apfel", "banane", "kirsche", "dattel"]
upper_letters = [wort.upper() for wort in words]
print(upper_letters)

