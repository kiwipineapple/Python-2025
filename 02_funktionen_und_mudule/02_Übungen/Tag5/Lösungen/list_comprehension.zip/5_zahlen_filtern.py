teilbare_zahlen = [x for x in range(1, 101) if x % 3 == 0 and x % 5 == 0]
print(teilbare_zahlen)