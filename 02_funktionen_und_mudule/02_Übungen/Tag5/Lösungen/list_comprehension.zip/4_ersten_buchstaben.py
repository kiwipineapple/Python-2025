wörter = ["Apfel", "Banane", "Kirsche", "Dattel"]
erste_buchstaben = [wort[0] for wort in wörter]
print(erste_buchstaben)