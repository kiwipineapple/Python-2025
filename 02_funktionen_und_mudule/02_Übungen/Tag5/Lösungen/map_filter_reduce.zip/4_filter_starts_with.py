# Funktion zur Filterung von Wörtern, die mit einem bestimmten Buchstaben beginnen
def filter_words(words, letter):
    # Verwende die filter()-Funktion, um Wörter zu finden, die mit dem angegebenen Buchstaben beginnen
    # Die Lambda-Funktion prüft, ob das Wort (in Kleinbuchstaben) mit dem Buchstaben beginnt
    return list(filter(lambda word: word.lower().startswith(letter.lower()), words))

# Beispiel-Liste von Wörtern
words = ["Apfel", "Banane", "Avocado", "Blaubeere", "Aprikose"]

# Aufruf der Funktion mit dem Buchstaben 'a'
result = filter_words(words, 'a')

# Erwartete Ausgabe: ['Apfel', 'Avocado', 'Aprikose']
print(result)
