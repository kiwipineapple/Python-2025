# Funktion zur Berechnung der Quadratwerte von Zahlen
def square_numbers(numbers):
    # Verwende die map()-Funktion, um das Quadrat jeder Zahl in der Liste zu berechnen
    # Die Lambda-Funktion nimmt eine Zahl und gibt ihr Quadrat zurück
    return list(map(lambda x: x ** 2, numbers))

# Testen der Funktion mit einer Beispiel-Liste von Zahlen
numbers = [1, 2, 3, 4, 5]

# Ergebnis der Funktion speichern
squared_numbers = square_numbers(numbers)

# Ausgabe der Liste mit Quadratwerten
print(squared_numbers)  # Erwartete Ausgabe: [1, 4, 9, 16, 25]
