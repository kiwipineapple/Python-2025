from functools import reduce


# Funktion zur Bestimmung des längsten Wortes in einer Liste
def find_longest_word(words):
    # Verwende die reduce()-Funktion, um das längste Wort in der Liste zu finden
    return reduce(lambda x, y: x if len(x) > len(y) else y, words)


# Beispiel-Liste von Wörtern
words = ["Apfel", "Banane", "Kaaaaaa", "Kirsche", "Mango"]

# Aufruf der Funktion
longest_word = find_longest_word(words)

# Ausgabe des längsten Wortes
print(longest_word)  # Erwartete Ausgabe: "Kirsche"


"""
gleich langen Wörtern: 
    lambda x, y: x if len(x) > len(y) else y
    
    Bei gleich langen Wörtern wird immer y beibehalten, was bedeutet, 
    dass das Wort, das später in der Liste kommt, ausgewählt wird, 
    wenn zwei Wörter die gleiche Länge haben.
    
    Beim Vergleich von "Kaaaaaa" und "Kirsche" sind beide 7 Zeichen lang, aber "Kirsche" wird zurückgegeben, 
    weil es als y das zuletzt verglichene Wort ist und len(x) > len(y) nicht wahr ist.
"""