# Funktion zum Filtern von geraden Zahlen
def filter_even_numbers(numbers):
    # Verwende die filter()-Funktion, um nur die geraden Zahlen aus der Liste zu extrahieren
    # Die Lambda-Funktion überprüft, ob eine Zahl gerade ist
    return list(filter(lambda x: x % 2 == 0, numbers))

# Testen der Funktion mit einer Beispiel-Liste
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Ergebnis der Funktion speichern
result = filter_even_numbers(numbers)

# Ausgabe der Liste mit nur geraden Zahlen
print(result)  # Erwartete Ausgabe: [2, 4, 6, 8, 10]
