# Funktion zur Umwandlung von Wörtern in Großbuchstaben
def uppercase_words(words):
    # Verwende die map()-Funktion, um jedes Wort in der Liste in Großbuchstaben umzuwandeln
    # Die Lambda-Funktion nimmt jedes Wort und gibt es in Großbuchstaben zurück
    return list(map(lambda word: word.upper(), words))

# Testen der Funktion mit einer Beispiel-Liste
words = ["python", "lernen", "macht", "spaß"]

# Ergebnis der Funktion speichern
result = uppercase_words(words)

# Ausgabe der Liste mit Wörtern in Großbuchstaben
print(result)  # Erwartete Ausgabe: ['PYTHON', 'LERNEN', 'MACHT', 'SPAß']
