quadrat = lambda x: x ** 2
ergebnis = quadrat(7)
print(ergebnis)  # Ausgabe: 49

