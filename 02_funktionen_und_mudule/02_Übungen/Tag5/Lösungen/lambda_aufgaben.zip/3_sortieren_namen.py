namen = ['Sophie', 'Anna', 'Maximilian', 'Ben', 'Charlotte']
sortiert_nach_laenge = sorted(namen, key=lambda x: len(x))
print(sortiert_nach_laenge)
# Ausgabe: ['Ben', 'Anna', 'Sophie', 'Charlotte', 'Maximilian']
