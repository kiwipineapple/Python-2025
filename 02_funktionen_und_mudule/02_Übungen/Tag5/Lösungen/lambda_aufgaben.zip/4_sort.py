# Liste von Zahlen
zahlen = [42, 17, 23, 56, 34]

# Sortieren in aufsteigender Reihenfolge
zahlen.sort()
print(zahlen)  # Ausgabe: [17, 23, 34, 42, 56]

# Sortieren in absteigender Reihenfolge
zahlen.sort(reverse=True)
print(zahlen)  # Ausgabe: [56, 42, 34, 23, 17]
