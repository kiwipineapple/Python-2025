personen = [ ('Anna', 25), ('Bernd', 32), ('Clara', 28), ('David', 21) ]


sortiert_nach_alter = sorted ( personen, key=lambda x: x[1]  )

print(sortiert_nach_alter)
# Ausgabe: [('David', 21), ('Anna', 25), ('Clara', 28), ('Bernd', 32)]



