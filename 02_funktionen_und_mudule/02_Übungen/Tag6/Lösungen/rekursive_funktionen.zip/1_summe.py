def summe(n):
    if n == 1:
        return 1  # Abbruchbedingung: summe(1) = 1
    return n + summe(n - 1)  # rekursiver Aufruf mit n-1

# Test
print(summe(5))  # Ausgabe: 15



""""
VORWÄRTS: Es wird immer summe(n-1) aufgerufen, bis n == 1

summe(5)
→ 5 + summe(4)
      → 4 + summe(3)
            → 3 + summe(2)
                  → 2 + summe(1)
                        → 1        (Abbruch erreicht!)  Rückgabe = 1


RÜCKWÄRTS: Jetzt geht alles wieder zurück – die Rechnungen laufen jetzt ab!

summe(1) → 1                       
→ summe(2) = 2 + 1   → ergibt 3         (1 kommt aus summe(1))  
→ summe(3) = 3 + 3   → ergibt 6         (3 kommt aus summe(2))  
→ summe(4) = 4 + 6   → ergibt 10        (6 kommt aus summe(3))  
→ summe(5) = 5 + 10  → ergibt 15        (10 kommt aus summe(4))  



"""