def umkehren(text):
    if text == "":
        return ""  # Abbruchbedingung: leerer String → Rückgabe ""
    return umkehren(text[1:]) + text[0]  # hänge erstes Zeichen ans Ende


print(umkehren("hallo"))  # Ausgabe: "ollah"

# Rekursion liest von vorne – und baut beim Rückweg den Text rückwärts wieder auf.
# Jeder Buchstabe wird beim Zurückgehen ans Ende gehängt.


"""
VORWÄRTS (Abstieg – immer kürzerer Text)

umkehren("hallo")
→ umkehren("allo") + "h"
      → umkehren("llo") + "a"
            → umkehren("lo") + "l"
                  → umkehren("o") + "l"
                        → umkehren("") + "o"
                              → ""   (Abbruchbedingung)

RÜCKWÄRTS (Aufbau des Rückgabewerts)

umkehren("")         → ""
→ "" + "o"           → "o"
→ "o" + "l"          → "ol"
→ "ol" + "l"         → "oll"
→ "oll" + "a"        → "olla"
→ "olla" + "h"       → "ollah"




"""