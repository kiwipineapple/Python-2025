def buchstaben_zaehlen(text):
    if text == "":
        return 0  # Abbruchbedingung: leerer String → Länge 0
    return 1 + buchstaben_zaehlen(text[1:])  # zähle 1 und arbeite mit Rest weiter

# Test
print(buchstaben_zaehlen("Hallo"))  # Ausgabe: 5



"""
VORWÄRTS (Aufrufe – immer kürzerer Text)

buchstaben_zaehlen("Hallo")
→ 1 + buchstaben_zaehlen("allo")
      → 1 + buchstaben_zaehlen("llo")
            → 1 + buchstaben_zaehlen("lo")
                  → 1 + buchstaben_zaehlen("o")
                        → 1 + buchstaben_zaehlen("")
                              → 0     (Abbruchbedingung erreicht!)

RÜCKWÄRTS (Zusammenzählen bei Rückgabe)
buchstaben_zaehlen("")         = 0
→ buchstaben_zaehlen("o")      = 1 + 0 = 1
→ buchstaben_zaehlen("lo")     = 1 + 1 = 2
→ buchstaben_zaehlen("llo")    = 1 + 2 = 3
→ buchstaben_zaehlen("allo")   = 1 + 3 = 4
→ buchstaben_zaehlen("Hallo")  = 1 + 4 = 5


"""