from textverarbeitung import *

text = "Python ist eine großartige Programmiersprache."

woerter = anzahl_woerter(text)
print("Anzahl der Wörter:", woerter)

buchstaben = anzahl_buchstaben(text)
print("Anzahl der Buchstaben:", buchstaben)

grossbuchstaben = text_in_grossbuchstaben(text)
print("Text in Großbuchstaben:", grossbuchstaben)
