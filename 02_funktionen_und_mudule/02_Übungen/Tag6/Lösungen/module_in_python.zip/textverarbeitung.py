def anzahl_woerter(text):
    woerter = text.split()
    return len(woerter)


def anzahl_buchstaben(text):
    buchstaben = len([char for char in text if char.isalpha()])
    return buchstaben


def text_in_grossbuchstaben(text):
    return text.upper()
