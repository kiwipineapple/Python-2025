import string

def ohne_zeichen(text):
    #Entfernt Satzzeichen aus dem Text.
    for zeichen in string.punctuation:
        text = text.replace(zeichen, "")
    return text

def nur_woerter(text):
    # Die Funktion geht jedes Zeichen im Text durch.
    # Sie erlaubt nur Buchstaben (a–z, A–Z) und Leerzeichen.
    # Alle anderen Zeichen wie Zahlen, Satzzeichen oder Sonderzeichen werden entfernt.
    # Am Ende wird alles in Kleinbuchstaben umgewandelt und zu einem neuen String zusammengesetzt.
    return ''.join([c.lower() for c in text if c.isalpha() or c == ' '])
