from .reinigung import ohne_zeichen, nur_woerter
from .dateien import zeilen_zaehlen, woerter_zaehlen
