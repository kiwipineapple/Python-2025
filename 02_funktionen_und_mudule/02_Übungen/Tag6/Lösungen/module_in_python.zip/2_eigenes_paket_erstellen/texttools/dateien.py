def zeilen_zaehlen(pfad):
    """Zählt die Anzahl der Zeilen in einer Datei."""
    with open(pfad, "r", encoding="utf-8") as f:
        return len(f.readlines())

def woerter_zaehlen(pfad):
    """Zählt die Anzahl der Wörter in einer Datei."""
    with open(pfad, "r", encoding="utf-8") as f:
        inhalt = f.read()
    return len(inhalt.split())
