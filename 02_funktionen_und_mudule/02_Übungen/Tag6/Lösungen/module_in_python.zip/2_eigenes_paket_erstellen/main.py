from texttools import ohne_zeichen, nur_woerter, zeilen_zaehlen, woerter_zaehlen

# Test für Textfunktionen
text = "Hallo, Welt! Python 3 ist super :)"
print("Original:", text)
print("Ohne Satzzeichen:", ohne_zeichen(text))
print("Nur Wörter:", nur_woerter(text))

# Test für Dateifunktionen
dateiname = "test.txt"  # Achte darauf, dass die Datei existiert

print("Anzahl Zeilen:", zeilen_zaehlen(dateiname))
print("Anzahl Wörter:", woerter_zaehlen(dateiname))
