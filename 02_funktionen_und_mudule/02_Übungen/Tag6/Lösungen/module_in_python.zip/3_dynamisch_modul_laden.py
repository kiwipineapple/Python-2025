import importlib

def wurzel_berechnen():
    """Fragt eine Zahl ab und berechnet die Quadratwurzel."""
    zahl = float(input("Gib eine Zahl ein, von der die Quadratwurzel berechnet werden soll: "))
    math = importlib.import_module("math")
    ergebnis = math.sqrt(zahl)
    print(f"Die Wurzel von {zahl} ist {ergebnis}")

def zufallszahl_erzeugen():
    """Fragt Start und Ende ab und erzeugt eine Zufallszahl."""
    start = int(input("Gib die Startzahl ein: "))
    ende = int(input("Gib die Endzahl ein: "))
    random = importlib.import_module("random")
    zahl = random.randint(start, ende)
    print(f"Zufallszahl zwischen {start} und {ende}: {zahl}")

def datum_anzeigen():
    """Zeigt das heutige Datum an."""
    datetime = importlib.import_module("datetime")
    print("Heute ist:", datetime.date.today())

def auswahl_menue():
    """Zeigt das Menü und verarbeitet die Auswahl."""
    while True:
        print("\nWas möchtest du tun?")
        print("1 – Quadratwurzel berechnen")
        print("2 – Zufallszahl erzeugen")
        print("3 – Aktuelles Datum anzeigen")
        print("4 – Beenden")

        wahl = input("Deine Auswahl: ")

        if wahl == "1":
            wurzel_berechnen()
        elif wahl == "2":
            zufallszahl_erzeugen()
        elif wahl == "3":
            datum_anzeigen()
        elif wahl == "4":
            print("Programm beendet.")
            break
        else:
            print("Bitte gib nur 1, 2, 3 oder 4 ein.")

# Programmstart
auswahl_menue()
