def odd_numbers_up_to(n):
    for x in range(1, n + 1, 2):
        yield x



# Testen der Funktion
for num in odd_numbers_up_to(10):
   print(num)  # Ausgabe: 1, 3, 5, 7, 9
