# Liste von Zeichenketten
words = ["Hallo", "an", "Welt", "Tag", "Python", "ist", "toll"]

# Generator-Ausdruck für Wörter, die länger als 3 Zeichen sind
long_words = (wort for wort in words if len(wort) > 3)

# Ausgabe der gefilterten Wörter
for wort in long_words:
    print(wort)  # Ausgabe: Hallo, Welt, Python, toll
