def count_down(n):
    while n > 0:
        yield n
        n -= 1

# Testen der Funktion
for num in count_down(5):
    print(num)  # Ausgabe: 5, 4, 3, 2, 1
