# Generator-Ausdruck für die Quadrate
quadrate = (x * x for x in range(1, 11))

# Ausgabe der Quadrate
for q in quadrate:
    print(q)  # Ausgabe: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100
