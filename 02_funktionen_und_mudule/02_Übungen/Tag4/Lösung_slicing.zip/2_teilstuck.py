my_list = [1, 2, 3, 4, 5, 6, 7]
# Greife auf die mittleren drei Elemente zu
mittlere_elemente = my_list[2:5]
print(mittlere_elemente)  # Ausgabe: [3, 4, 5]
