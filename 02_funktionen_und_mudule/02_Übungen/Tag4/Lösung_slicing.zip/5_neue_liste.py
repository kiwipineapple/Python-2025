my_list = [1, 2, 3, 4, 5]
# Entferne das dritte Element durch Slicing und Neuzusammenstellung der Liste
my_list = my_list[:2] + my_list[3:]
print(my_list)  # Ausgabe: [1, 2, 4, 5]
