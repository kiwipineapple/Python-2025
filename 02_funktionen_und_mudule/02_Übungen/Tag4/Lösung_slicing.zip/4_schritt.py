my_list = [1, 2, 3, 4, 5, 6, 7, 8]
# Greife auf jedes zweite Element zu
jedes_zweite = my_list[::2]
print(jedes_zweite)  # Ausgabe: [1, 3, 5, 7]
