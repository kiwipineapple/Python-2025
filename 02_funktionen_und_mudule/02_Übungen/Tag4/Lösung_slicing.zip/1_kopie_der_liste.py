my_list = [1, 2, 3, 4, 5]
# Kopiere die gesamte Liste mit Slicing
kopie = my_list[:]
print(kopie)  # Ausgabe: [1, 2, 3, 4, 5]
