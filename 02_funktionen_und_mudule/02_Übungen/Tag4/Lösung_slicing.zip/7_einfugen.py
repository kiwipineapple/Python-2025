my_list = [1, 2, 3, 4, 5]
# Füge die Elemente nach dem zweiten Element ein
my_list[2:2] = [10, 11]
print(my_list)  # Ausgabe: [1, 2, 10, 11, 3, 4, 5]
