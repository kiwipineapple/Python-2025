my_list = [1, 2, 3, 4, 5]
# Verwende Slicing, um die Liste umzukehren
umgekehrt = my_list[::-1]
print(umgekehrt)  # Ausgabe: [5, 4, 3, 2, 1]
