my_list = [1, 2, 3, 4, 5, 6, 7]

#x = slice(-3:) Muss man None geben. Gibts keine default wert
#print(my_list[x])

# Greife auf die letzten drei Elemente zu
letzte_drei = my_list[-3:]
print(letzte_drei)  # Ausgabe: [5, 6, 7]