my_list = [1, 2, 3, 4, 5, 6, 7, 8]
# Ersetze die Elemente von Index 2 bis 5 durch eine kürzere Liste
my_list[2:6] = [100, 101]
print(my_list)  # Ausgabe: [1, 2, 100, 101, 7, 8]
