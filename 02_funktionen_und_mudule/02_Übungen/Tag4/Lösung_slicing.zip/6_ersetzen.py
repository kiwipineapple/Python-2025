my_list = [1, 2, 3, 4, 5]
# Ersetze das vierte Element durch 100
my_list[3:4] = [100]
print(my_list)  # Ausgabe: [1, 2, 3, 100, 5]
