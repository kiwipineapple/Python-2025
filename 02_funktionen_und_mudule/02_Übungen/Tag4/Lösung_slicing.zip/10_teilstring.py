my_string = "Hallo Welt"
# Verwende Slicing, um den Teilstring "Welt" zu extrahieren
teilstring = my_string[6:]
print(teilstring)  # Ausgabe: Welt

