def multiply(a, b):
    return a * b

print(multiply(4, 5))      # Ausgabe: 20
print(multiply(b=5, a=4))  # Ausgabe: 20
