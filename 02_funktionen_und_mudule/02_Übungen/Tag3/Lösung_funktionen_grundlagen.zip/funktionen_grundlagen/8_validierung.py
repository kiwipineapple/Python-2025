def is_positive_number(number):
    return number > 0

print(is_positive_number(5))   # Ausgabe: True
print(is_positive_number(-3))  # Ausgabe: False
print(is_positive_number(0))   # Ausgabe: False
