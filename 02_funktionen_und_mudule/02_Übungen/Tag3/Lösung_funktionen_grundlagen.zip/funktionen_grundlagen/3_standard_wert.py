def greeting(name, gruess="Hello"):
    return f"{gruess}, {name}!"

print(greeting("Peter"))           # Ausgabe: "Hello, Peter!"
print(greeting("Anna", "Good day"))  # Ausgabe: "Good day, Anna!"
