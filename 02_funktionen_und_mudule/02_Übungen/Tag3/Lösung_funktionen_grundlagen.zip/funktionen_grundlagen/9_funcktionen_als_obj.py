import random

# Drei verschiedene Funktionen definieren
def sag_hallo():
    print("Hallo, schön dich zu sehen!")

def motivation():
    print("Du schaffst das! Weiter so!")

def entspannung():
    print("Atme tief durch... Alles ist gut.")

# Funktionen in einer Liste speichern
aktionen = [sag_hallo, motivation, entspannung]

# Eine zufällige Funktion auswählen
zufall = random.choice(aktionen)
print(zufall)
# Die ausgewählte Funktion ausführen
zufall()


# 💡 Reflexion:
# Funktionen können – wie Zahlen oder Strings – in einer Liste gespeichert und bearbeitet werden.
# Aber im Gegensatz zu Zahlen sind Funktionen "ausführbar":
# Man kann sie nicht nur speichern, sondern auch direkt aufrufen – z.B. zufall()
# Dadurch wird der Code flexibler: Man kann je nach Situation unterschiedliche Aktionen ausführen,
# ohne viele if/else-Bedingungen zu schreiben.
