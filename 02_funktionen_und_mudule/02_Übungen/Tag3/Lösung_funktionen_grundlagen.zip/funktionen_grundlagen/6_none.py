def print_message(message):
    print(message)


result = print_message("Hello, world!")
print(result)  # Ausgabe: None
