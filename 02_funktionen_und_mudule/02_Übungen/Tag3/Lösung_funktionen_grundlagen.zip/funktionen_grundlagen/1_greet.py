def greet(name):
    return f"Hello, {name}!"

print(greet("Maria"))  # Ausgabe: "Hello, Maria!"
