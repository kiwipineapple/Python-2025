def calculate(a, b):
    sum_value = a + b
    product = a * b
    return sum_value, product


sum_value, product = calculate(3, 7)

print("Sum:", sum_value)  # Ausgabe: Sum: 10
print("Product:", product)  # Ausgabe: Product: 21

# print(calculate(5,6))
# print(type(calculate(5,6)))