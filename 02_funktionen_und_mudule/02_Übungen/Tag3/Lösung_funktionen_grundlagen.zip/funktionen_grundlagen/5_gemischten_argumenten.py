def power(base, exponent):
    return base ** exponent

print(power(2, exponent=3))  # Ausgabe: 8
