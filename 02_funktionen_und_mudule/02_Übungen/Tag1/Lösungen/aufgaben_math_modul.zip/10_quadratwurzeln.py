import math
for i in range(1, 11):
    print(f"Wurzel von {i}: {math.sqrt(i):.2f}")
