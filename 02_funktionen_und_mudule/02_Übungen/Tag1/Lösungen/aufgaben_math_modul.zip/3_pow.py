import math
print(math.pow(2, 8))       # 256.0 (float)
print(2 ** 8)            # 256 (int)

print(type(math.pow(2, 8)))
print(type(2 ** 8))
