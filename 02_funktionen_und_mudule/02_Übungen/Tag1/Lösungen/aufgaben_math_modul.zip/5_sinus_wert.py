import math
print(math.sin(math.radians(90)))  # 1.0
