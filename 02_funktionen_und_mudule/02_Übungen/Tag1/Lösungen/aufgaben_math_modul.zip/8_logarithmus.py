import math

# Gibt den natürlichen Logarithmus (zur Basis e ≈ 2.718) von 100 aus
# Dies entspricht: ln(100)
# Hinweis: Wenn kein Basis-Parameter angegeben wird, verwendet Python standardmäßig die Eulersche Zahl als Basis.
print(math.log(100))        # ≈ 4.605170...

# Gibt den Logarithmus von 100 zur Basis 10 aus
# Dies entspricht: log₁₀(100) = 2
print(math.log(100, 10))    # 2.0

# Gibt den Logarithmus von 100 zur Basis 2 aus
# Dies entspricht: log₂(100) ≈ 6.6438
print(math.log(100, 2))     # ≈ 6.643856...
