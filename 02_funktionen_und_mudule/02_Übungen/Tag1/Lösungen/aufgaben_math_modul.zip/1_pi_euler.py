import math
print(math.pi)
print(math.e)
