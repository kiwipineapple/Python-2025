import math
print(f"{math.pi:.6f}")  # 3.141593
print(round(math.pi,6))



print(round(math.pi)) # Rundet π auf die nächste ganze Zahl → Standardrundung

print(round(3.5)) # 4 nächste gerade Zahl
print(round(4.5)) # 4 nächste gerade Zahl

# Python verwendet bei .5-Werten das sogenannte "Banker's Rounding":
# Wenn genau zwischen zwei Zahlen, wird auf die nächste gerade Zahl gerundet