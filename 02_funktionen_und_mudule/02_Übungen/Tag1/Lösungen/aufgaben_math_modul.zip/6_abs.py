import math
print(abs(-5))       # 5 (int)
print(math.fabs(-5)) # 5.0 (float)
