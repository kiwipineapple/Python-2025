import math
print(math.floor(3.7))  # 3
print(math.ceil(3.7))   # 4
print(math.floor(-2.4)) # -3
print(math.ceil(-2.4))  # -2
