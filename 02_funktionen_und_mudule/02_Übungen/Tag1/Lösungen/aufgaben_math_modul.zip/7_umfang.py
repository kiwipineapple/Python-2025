import math
radius = 7
umfang = 2 * math.pi * radius
print(umfang)
