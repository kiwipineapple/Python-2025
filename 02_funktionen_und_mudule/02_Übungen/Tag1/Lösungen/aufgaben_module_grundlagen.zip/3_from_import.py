from rechenoperationen import multipliziere

ergebnis = multipliziere(4, 7)
print("Das Ergebnis der Multiplikation ist:", ergebnis)

# rechenoperationen.dividiere(4,2)
# dividiere(4,2)
"""
Was passiert, wenn du versuchst, eine Funktion zu verwenden, die du nicht explizit importiert hast?

Antwort: Wenn man versucht, eine Funktion zu verwenden, die nicht explizit importiert wurde, 
erhält man einen NameError, da die Funktion im aktuellen Namensraum nicht verfügbar ist.

"""