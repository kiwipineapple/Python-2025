import rechenoperationen as ro

print("12 + 8 =", ro.addiere(12, 8))
print("100 - 25 =", ro.subtrahiere(100, 25))
print("9 * 11 =", ro.multipliziere(9, 11))
print("45 / 9 =", ro.dividiere(45, 9))
