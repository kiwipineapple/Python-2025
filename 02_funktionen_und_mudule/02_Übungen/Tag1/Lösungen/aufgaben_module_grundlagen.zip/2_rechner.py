import rechenoperationen

print("10 + 5 =", rechenoperationen.addiere(10, 5))
print("15 - 8 =", rechenoperationen.subtrahiere(15, 8))
print("7 * 6 =", rechenoperationen.multipliziere(7, 6))
print("20 / 4 =", rechenoperationen.dividiere(20, 4))

# rechenoperationen.meaw()

"""
 Wenn man versucht, eine Funktion aufzurufen, die nicht im Modul definiert ist, erhält man einen 
 AttributeError, der besagt, dass das Modul das entsprechende Attribut (Funktion) nicht besitzt.

"""