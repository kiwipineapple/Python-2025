car = {"brand": "Toyota", "model": "Corolla", "year": 2010}  # Dictionary erstellen
car["color"] = "blue"  # Neuen Schlüssel hinzufügen
car["year"] = 2022  # Wert von "year" aktualisieren
print(car)  # Ausgabe des endgültigen Dictionarys

for item, value in car.items():  # Durch das Dictionary iterieren
    print(f"{item}: {value}")  # Ausgabe von Schlüssel und Wert