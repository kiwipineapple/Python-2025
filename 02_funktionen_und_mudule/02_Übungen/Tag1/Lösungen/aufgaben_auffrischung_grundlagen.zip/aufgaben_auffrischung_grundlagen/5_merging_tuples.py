tuple1 = (1, 2, 3)  # Erstes Tuple erstellen
tuple2 = (4, 5, 6)  # Zweites Tuple erstellen
merged_tuple = tuple1 + tuple2  # Tuples kombinieren
print(merged_tuple)  # Ausgabe des kombinierten Tuples
