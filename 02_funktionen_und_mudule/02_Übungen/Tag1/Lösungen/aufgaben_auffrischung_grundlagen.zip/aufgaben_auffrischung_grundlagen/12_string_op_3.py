wort = "Programmieren"
print(wort[:5])
print(wort[-4:]) # print(wort[9:])
print(wort[::2])
print(wort[::-1])