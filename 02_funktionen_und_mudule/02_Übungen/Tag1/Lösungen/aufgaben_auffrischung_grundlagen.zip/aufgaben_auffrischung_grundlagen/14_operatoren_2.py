x = 5
y = 10
z = x

ist_gleich = x == y
zwischenwert = x < y and x > 2
# zwischenwert = y > x > 2

bedingung1 = x != y or z > 3
identisch = x is z

print("x und y sind gleich:", ist_gleich)
print("x liegt zwischen 2 und y:", zwischenwert)
print("Bedingung erfüllt:", bedingung1)
print("x und z sind identisch:", identisch) #True

a = 5
print("x und a sind identisch:", x is a) # True


# In Python werden kleine Ganzzahlen (typischerweise von -5 bis 256) intern zwischengespeichert („interned“).
# Das bedeutet, dass alle Variablen mit dem gleichen Wert im selben Speicherobjekt gespeichert werden,
# um Ressourcen zu sparen. Daher liefert der Vergleich mit „is“ bei solchen Zahlen True.

list_1 = [1, 2]
list_2 = [1, 2]
print(list_1 == list_2)  # True — der Inhalt beider Listen ist gleich
print(list_1 is list_2)  # False — es sind zwei verschiedene Objekte im Speicher

# == prüft, ob die Inhalte gleich sind
# is prüft, ob beide Variablen auf dasselbe Objekt im Speicher verweisen
# Bei Listen mit gleichem Inhalt, die separat erstellt wurden, ist „==“ True, aber „is“ False
