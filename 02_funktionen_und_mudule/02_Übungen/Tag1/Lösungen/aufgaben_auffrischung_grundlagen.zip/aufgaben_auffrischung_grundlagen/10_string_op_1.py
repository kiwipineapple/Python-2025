text = "Hallo Python Welt"
print(len(text))
print(text.upper())
print(text.replace("Welt", "Community"))