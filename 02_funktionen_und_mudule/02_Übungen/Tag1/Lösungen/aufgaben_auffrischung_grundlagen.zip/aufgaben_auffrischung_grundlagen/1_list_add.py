fruits = ["apple", "banana", "cherry"]  # Liste erstellen
fruits.append("orange")  # "orange" am Ende hinzufügen
fruits.insert(0, "grape")  # "grape" am Anfang hinzufügen
print(fruits)  # Ausgabe der endgültigen Liste
