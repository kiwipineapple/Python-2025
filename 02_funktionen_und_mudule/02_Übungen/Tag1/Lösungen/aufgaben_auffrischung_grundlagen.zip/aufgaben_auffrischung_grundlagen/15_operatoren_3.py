farben = ["rot", "grün", "blau"]
text = "Programmieren macht Spaß"
gruen_drin = "grün" in farben
gelb_nicht_drin = "gelb" not in farben
buchstabe_drin = "S" in text
wort_nicht_drin = "lernen" not in text
print(gruen_drin, gelb_nicht_drin, buchstabe_drin, wort_nicht_drin)