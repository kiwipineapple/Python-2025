temperature = 30

if temperature > 30:
    print("Zu heiß")
elif temperature < 10:
    print("Zu kalt")
else:
    print("Angenehm")