person = ("Alice", 25, "Engineer")  # Tuple erstellen
name, age, profession = person  # Tuple entpacken
print(name)  # Ausgabe des Namens
print(age)  # Ausgabe des Alters
print(profession)  # Ausgabe des Berufs
