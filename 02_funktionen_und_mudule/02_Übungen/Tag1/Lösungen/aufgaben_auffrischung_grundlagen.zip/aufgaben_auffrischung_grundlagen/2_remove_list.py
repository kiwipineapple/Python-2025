numbers = [1, 2, 3, 4, 5]  # Liste erstellen
numbers.remove(3)  # Entfernt die Zahl 3
print(numbers)  # Ausgabe der Liste nach dem Entfernen von 3
numbers.pop()  # Entfernt das letzte Element
print(numbers)  # Ausgabe der Liste nach dem Entfernen des letzten Elements
