coordinates = (10, 20, 30)  # Tuple erstellen
first = coordinates[0]  # Zugriff auf das erste Element
last = coordinates[-1]  # Zugriff auf das letzte Element
print(first)  # Ausgabe des ersten Elements
print(last)  # Ausgabe des letzten Elements
