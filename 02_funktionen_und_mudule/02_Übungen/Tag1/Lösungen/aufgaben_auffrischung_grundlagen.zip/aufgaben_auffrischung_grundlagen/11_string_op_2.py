name = "Anna Müller"
vorname, nachname = name.split()
satz = f"Hallo, {vorname} {nachname}! Schön, dass du da bist."
print(satz)
#print(name.split())
#print(name.split("M"))