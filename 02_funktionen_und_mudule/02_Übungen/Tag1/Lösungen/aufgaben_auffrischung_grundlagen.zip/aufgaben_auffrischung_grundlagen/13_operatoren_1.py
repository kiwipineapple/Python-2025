a = 17
b = 4
ganze_anzahl = a // b
rest = a % b
anteil = a / b
potenz = a ** b
print("Ganze Anzahl:", ganze_anzahl)
print("Rest:", rest)
print("Anteil:", anteil)
print("Potenz:", potenz)