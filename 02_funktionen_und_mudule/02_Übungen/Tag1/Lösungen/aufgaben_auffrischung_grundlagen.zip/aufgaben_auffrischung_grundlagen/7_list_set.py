liste = [1, 2, 2, 3, 4, 4, 5]
unique_numbers = set(liste)
print(unique_numbers)