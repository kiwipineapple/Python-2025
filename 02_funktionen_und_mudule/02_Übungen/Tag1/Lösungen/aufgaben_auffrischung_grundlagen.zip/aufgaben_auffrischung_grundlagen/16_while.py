korrektes_passwort = "python123"
eingabe = ""
while eingabe != korrektes_passwort:
    eingabe = input("Bitte Passwort eingeben: ")
print("Zugriff erlaubt")