useDb("WeatherDB")

// 1. "breezy" zu Berlin hinzufügen
db.weather2.updateOne(
  { city: "Berlin" },
  { $push: { phenomena: "breezy" } }
)

// 2. "sunny" nur hinzufügen, wenn noch nicht vorhanden
db.weather2.updateOne(
  { city: "Berlin" },
  { $addToSet: { phenomena: "sunny" } }
)

// 3. "dry" aus Berlin entfernen
db.weather2.updateOne(
  { city: "Berlin" },
  { $pull: { phenomena: "dry" } }
)

// 4. Erstes Phänomen bei London entfernen
db.weather2.updateOne(
  { city: "London" },
  { $pop: { phenomena: -1 } }
)

// 5. Letztes Phänomen bei Paris entfernen
db.weather2.updateOne(
  { city: "Paris" },
  { $pop: { phenomena: 1 } }
)

// 6. 26 und 27 zu Paris hinzufügen
db.weather2.updateOne(
  { city: "Paris" },
  { $push: { measurements: { $each: [26, 27] } } }
)

// 7. Alle mit "storm"
db.weather2.find({ phenomena: "storm" })

// 8. Alle ohne "sunny"
db.weather2.find({ phenomena: { $ne: "sunny" } })

// 9. Alle, wo 29 in measurements vorkommt
db.weather2.find({ measurements: 29 })

// 10. Alle mit mehr als 3 Messwerten
db.weather2.find({ "measurements.3": { $exists: true } })

// 11. Leeres Array-Feld tags zu allen hinzufügen
db.weather2.updateMany({}, { $set: { tags: [] } })

// 12. Berlin: "summer" und "dry" gleichzeitig zu tags hinzufügen
db.weather2.updateOne(
  { city: "Berlin" },
  { $push: { tags: { $each: ["summer", "dry"] } } }
)

// 13. "dry" wieder aus tags von Berlin entfernen
db.weather2.updateOne(
  { city: "Berlin" },
  { $pull: { tags: "dry" } }
)
