useDb("WeatherDB")

// 1. Alle Wetterdaten von Berlin
db.weather.find({ city: "Berlin" })

// 2. Alle Einträge mit Regen
db.weather.find({ rain: true })

// 3. Temperatur unter 20 Grad
db.weather.find({ temperature: { $lt: 20 } })

// 4. Windgeschwindigkeit über 20 km/h
db.weather.find({ wind: { $gt: 20 } })

// 5. Trockene Tage mit Luftfeuchtigkeit über 60 %
db.weather.find({ rain: false, humidity: { $gt: 60 } })

// 6. Regen und Temperatur über 25 Grad
db.weather.find({ rain: true, temperature: { $gt: 25 } })

// 7. Nur Stadt und Temperatur, ohne _id
db.weather.find({}, { city: 1, temperature: 1, _id: 0 })

// 8. Nach Temperatur absteigend sortieren
db.weather.find().sort({ temperature: -1 })

// 9. Einträge vom 2. Juli 2023
db.weather.find({ date: "2023-07-02" })

// 10. Städte mit maximal 60 % Luftfeuchtigkeit
db.weather.find({ humidity: { $lte: 60 } })
